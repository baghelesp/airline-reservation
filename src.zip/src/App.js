import React, { useState, useEffect } from 'react';
import {BrowserRouter,Link,Route,Routes,Navigate} from'react-router-dom'
import Home from './component/home/Home';
import Booking from './component/searchbar/booking/Booking';
import FlightStatus from './component/searchbar/flightstatus/FlightStatus'
import Checkin from './component/searchbar/Checkin';
function App() {
  
  return (
    <div className="App">
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Home/>} >
        <Route  path='/' element={<Navigate replace to="/booking"/>} ></Route>
        <Route path='/booking' element={<Booking/>}></Route>
        <Route path='/status' element={<FlightStatus/>}></Route>
        <Route path='/checkin' element={<Checkin/>}></Route>
        </Route>
        
         
       
        
      </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
