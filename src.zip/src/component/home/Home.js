import React, { useState, useEffect } from 'react';
import Loading from './Loading';
import Header from '../header/Header';
import Searchbox from '../searchbar/Searchbox';

function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading for 2 seconds
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  return (
    <div className="App">
      {isLoading ? (
        <Loading />
      ) : (
       <>
        <Header/>
        <Searchbox/>
        {/* <div style={{height:"1300px"}}>
        </div> */}
        </>
      )}
    </div>
  );
}

export default Home;
