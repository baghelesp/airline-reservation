import React from "react";
import Navbar from "./navbar/Navbar";

function Header(){
    return <><div >
        <Navbar/>
        {/* <img style={{width:"100%"}} src="/bg-img.jpg" alt="img not found"/> */}
        <video autoPlay loop muted style={{width:"100%", maxHeight:"70%"}} >
            <source src="/bg-v.mp4" type="video/mp4"/>
        </video>
        </div></>
}
export default Header;