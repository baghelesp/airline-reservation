import Form from "../form/Form";
function Booking(){
    return <><Form/></>
}
export default Booking;