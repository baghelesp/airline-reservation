import { Link, Outlet } from "react-router-dom";
import './Navbar.css'
function Navbar(){
    return<>
    <div style={{ display:"flex", width:"100%", margin:"auto"}}>
    <Link className="link"   to="/booking" >Book</Link>
    <Link className="link" to="/status" >Flight Status</Link>
    <Link className="link" to="/checkin" >manage/checkin</Link>
    </div>
    
    </>
}
export default Navbar;