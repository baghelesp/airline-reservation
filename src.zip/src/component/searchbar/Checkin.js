function Checkin()
{
    return<>manage Checkin</>
}
export default Checkin;